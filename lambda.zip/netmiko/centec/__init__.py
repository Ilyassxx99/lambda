from netmiko.centec.centec_os import CentecOSSSH, CentecOSTelnet

__all__ = ["CentecOSSSH", "CentecOSTelnet"]
