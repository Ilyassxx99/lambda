from netmiko.mikrotik.mikrotik_ssh import MikrotikRouterOsSSH
from netmiko.mikrotik.mikrotik_ssh import MikrotikSwitchOsSSH

__all__ = ["MikrotikRouterOsSSH", "MikrotikSwitchOsSSH"]
